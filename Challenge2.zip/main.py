def recurfact(n):
  if n == 0 or n == 1:
    return 1
  else:
    return n * recurfact(n - 1)


number = int(input("ENTER THE NUMBER:"))
res = recurfact(number)
print("THE FACTORIAL", number, "IS", res)
